# springboot-datajpa-joins

Spring boot Data JPA with Relations and Joins examples

Inner Join, Left Join, Right Join and Cross Join

Step 1 : Run the application as a Spring boot application and Tables will be created automatically

Step 2 : Insert the data into the both the tables

Step 3 : Test the Application with the Rest API
